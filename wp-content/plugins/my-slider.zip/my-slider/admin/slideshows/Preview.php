<?php

if (!defined('ABSPATH')) die('No direct access.');

/**
 * Class to handle the preview functionality
 */
class MetaSlider_Slideshow_Preview {
	
}
